var APP_DATA = {
  "scenes": [
    {
      "id": "0-panorama_2022150-allstate-chicago-river-point_working-rendering-file_tfortino_2022-10-17-14-55-35",
      "name": "Panorama_2022.150 Allstate Chicago River Point_WORKING RENDERING FILE_Tfortino_2022-10-17-14-55-35",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.7383947579085373,
          "pitch": 0.13639121206290739,
          "rotation": 6.283185307179586,
          "target": "1-panorama_2022150-allstate-chicago-river-point_working-rendering-file_tfortino_2022-10-17-15-35-28"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 1.9661590038055818,
          "pitch": 0.054156163887130404,
          "title": "Title",
          "text": "Text"
        }
      ]
    },
    {
      "id": "1-panorama_2022150-allstate-chicago-river-point_working-rendering-file_tfortino_2022-10-17-15-35-28",
      "name": "Panorama_2022.150 Allstate Chicago River Point_WORKING RENDERING FILE_Tfortino_2022-10-17-15-35-28",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
